
# Security Principles

1. **Consider Human Factors**
	1. A solution should be usable by ordinary people, it must not be too inconvenient or else the users will unintentionally introduce flaws(sticky notes with passwords on)
2. **Security is economics**
	1. The cost of a breach should be taking into account when securing an item, the cost of security should be proportional to the cost of breach.
3. **Detect if you cant prevent**
	1. In some situations it can be too expensive to completely prevent attacks, but you should at least be able to detect that you've been attacked. 
4. **Defense in depth**
	1. Basically layered defense , making the attacker have to go through multiple layers inorder to gain access, reduces their chances of succesfully executing an attack. 
5. **Least privilege**
	1. Ensure that users only have the necessary rights in order for them to execute their task. Never more than necessary. 
6. **Separation of responsibility**
	1. Pertains to splitting up the rights such that no person or program can have complete power over a system. 
7. **Ensure complete mediation**
	1. One way to do it is through reference monitors, where each and every access to every objects needs to pass through one or few gates, such that they can be monitored. 
8. **Shannon's Maxim**
	1. States that the attackers knows the system that they are attacking. 
	2. This means that one can't rely on security by obscurity; there are more reason though, firstly it's difficult to maintain and it's very brittles. Assuming Shannon's maxim is true, avoids such mistakes. 
9. **Use fail-safe defaults**
	1. When an action fails, it should always result in a safe state. 
	2. Like, if a password service is down, it should not lead to every passwords allowing for access. 
10. **Design security in from the start**
	1. It's easier and therefore less costly to implement security as early as possible in a given project. 
11. **The Trusted Computing Base**
	1. TCB is the part of a system that must operate correctly in order for the security goals of the system to be assured. Anything in the TCB must be relied upon, conversely anything outside of TCB should be not relied upon in anyway. 
	2. The TCB should therefore be as small as possible. 
	3. *Design principles for TCB*
		1. Unbypassable(or Completeness) - Bypassing the TCB must in no way lead to breaching the system security.
		2. Tamper-resistant(or Security) - TCB should be protected from tampering. Other services must not be able to modify the TCB's code or state.
		3. Verifiable(or Correctness) - The TCB's correctness must be verifiable.  
12. **TOCTTOU Vulnerabilities**
	1. Meaning "The time of check to time of use"
	2. Race conditions falls under this category, as another process can introduce mistakes while you're executing a task. 

# From slides:
**Example of security goals**
![[Pasted image 20241223175620.png]]
## Principles introduced in the slides
1. Economy of Mechanism *Economy og security*
	1.  Keep it simple
	2. Complex designs yields complex failure analysis
2. Open Design *Shannon's maxim*
	1. Kerchoffs principle
	2. Shannon's maxim
	3. A system should not depend on the secrecy of its protection mechanisms
3. Minimum exposure *Least privilige*
	1. Minimize the attack surface a system presents to the adversary
		1. Reduce external interfaces
		2. Limit information
		3. Limit window of opportunity
4. No single point of failure *Defense in depth*
	1. Build redundant security mechanisms whenever feasible
	2. Separation of duty
5. Psychological acceptability *Consider human factors*
	1. Design usable security mechanisms

# Exercises
**1.1 What is meant by the CIA triad?**
It's the basis for Security goals - Confidentiality - Integrity and Availability.

**1.5 What is a security policy? What are the actions involved when implementing a security policy?**
ChatGPT: 

A **security policy** is a formalized document that outlines the rules, guidelines, and practices designed to protect an organization's information, systems, and resources from unauthorized access, misuse, or disruption. It serves as a foundation for establishing secure practices and compliance with legal and regulatory requirements.

### Key Components of a Security Policy

1. **Purpose and Scope**: Defines the objectives and the areas or systems covered.
2. **Roles and Responsibilities**: Specifies who is responsible for enforcing and adhering to the policy.
3. **Standards and Guidelines**: Provides the framework for acceptable behavior and technical configurations.
4. **Incident Response**: Outlines steps to be taken in case of a security breach or issue.
5. **Compliance**: Ensures adherence to legal, regulatory, and organizational requirements.
6. **Review and Updates**: Sets the schedule for policy review and updates to reflect evolving risks.

---

### Actions Involved When Implementing a Security Policy

1. **Risk Assessment**:
    
    - Identify assets (data, systems, people).
    - Evaluate threats and vulnerabilities.
    - Assess the potential impact of security breaches.
2. **Define Objectives and Scope**:
    
    - Specify what the policy aims to achieve (e.g., protecting sensitive data).
    - Determine which systems, processes, and users are covered.
3. **Develop the Policy**:
    
    - Create clear, actionable rules and guidelines.
    - Align the policy with regulatory and industry standards.
4. **Obtain Management Approval**:
    
    - Present the draft to stakeholders and senior management for feedback and endorsement.
5. **Communicate the Policy**:
    
    - Train employees and stakeholders to understand and comply with the policy.
    - Distribute the policy document widely across the organization.
6. **Implement Security Controls**:
    
    - Deploy technical, administrative, and physical controls to enforce the policy (e.g., firewalls, access controls, and surveillance systems).
7. **Monitor and Enforce**:
    
    - Track adherence to the policy using audits and monitoring tools.
    - Take corrective action when violations occur.
8. **Incident Management**:
    
    - Establish procedures for detecting, reporting, and addressing security incidents.
    - Maintain a response plan for timely resolution.
9. **Review and Update Regularly**:
    
    - Periodically evaluate the policy’s effectiveness.
    - Update the policy to address emerging risks and changes in the business environment.

Implementing a security policy requires collaboration across departments, continual assessment, and a commitment to maintaining a secure organizational culture.
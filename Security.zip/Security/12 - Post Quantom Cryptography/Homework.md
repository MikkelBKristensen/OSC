
# What is Post-Quantum Cryptography(PQC)?

**Notes**
* post-quantum encryption algorithms
	* Are algorithms that are secure against attacks from quantum computers
* Quantum computing
	* Draws on quantum properties which enable a bit of data to act as both a 0 and 1 at the same time, enabling calculations that would be difficult or impossible for a conventional computer.
	* With powerful processors would be able to sift through many solutions to a problem simultaneously, guessing an answer very quickly.
* Many encryption algorithms rely on normal computers having difficulty with factoring large numbers, this difficulty is not present in quantum computers. 
* PQC's are needed as in the event of cryptographically relevant computer, all non-PGC encryption schemes must retire. 
	* This effects normal encryptions schemes, but also signatures and authentication
* The 4 PQC algorithms chosen by NIST
	* Are based on either **Structured Lattices** or **Hash functions**
* Harvest now, decrypt later
	* An expression used when an attackers harvest som encrypted data that might still be relevant long into the future with the intention to use a quantum computer to break the encryption later.
* PQC is different from QC
	* As PQC deals against quantum computers with any means necessary, like old greek elliptics
	* QC is about using quantum computing to make new secure encryption schemes. 

# Report on Post-Quantum Cryptography by Lily Chen, Stephen Jordan, Yi-Kai .... etc

## Intro
Most crucial communication relies on: public key encryption, digital signatures and key exchange - These are primarily implemented using:  Diffie-Hellman key exchange, RSA cryptosytem and elliptic curve cryptosystem.
Using the difficulty of solving "Integer Facorization" or "Discrete Log Problem over various groups" as security guarantee. 

In 1994 Peter Shor showed how Quantum Computers(QC) could solve these problems efficiently using properties of matter and energy to perform these calculations. 

![[Pasted image 20250104131441.png]]


## Overview of Quantum-Resistant Cryptography
Public key cryptography are used for digital signatures and key establishment, and as they would be insecure in the event of a large-scale Quantum Computer researchers have searched for such algorithms that are resistant to attacks from both conventional and QCs.

#### Lattice based cryptography
Crypto systems based on lattices problems have gained popularity, as they are relatively simple efficient and highly parallelizable. Some of these systems are also provably secure under a worst-case hardness assumption.
The downside of them being that it is difficult to give precise estimates of the security of lattice schemes against even known cryptanalysis techniques. 

#### Multivariate polynomial cryptography
These schemes are based on the difficulty of solving systems of multivariate polynomials over finite fields. Theses schemes have historically been successful when concerning signatures - But many of this type of cryptosystems that have been proposed have also been broken.

#### Hash-based signatures
Their security against quantum attacks is well understood, but has some drawbacks:
1. The signer must keep a record of the exact number of previously signed messages, and any error will result in insecurity
2. They can only produce a limited number of signatures, without increasing the signature size at least.

# Post-Quantum cryptography shielding us against quantum-computer fallout

Shor's algorithm breaks RSA public key system. As the proposed algorithm efficiently can solve for Integer Factors, which is the underlying security in RSA. 


Basically expands on the mathematical properties of the above mentioned PQCs. 



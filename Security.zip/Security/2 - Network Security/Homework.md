
## 25 Introduction to networking
**LAN** A network where each machine is connected to all other machines. A **router** is used to connect multiple LAN's. A message from LAN A to LAN B needs to be send through the router. The basis of the internet is **WAN**(Wide Area Network) which follows the schematic of a lot of LAN's connected through routers. 
**Outdated OSI 7-layer model** that depicts the different abstraction layers in network:
![[Pasted image 20240903174917.png]]
Each layer has its own set of **protocols**, which unifies how to communicate. The protocols contains the structure of the communication, how machines should behave while communicating and errorhandling. The protocols are supported by headers which contains necessary **metadata** such as sender and recipient Id, length of message, ID numbers an more. 

The **link layer** uses 48-bit MAC addresses to uniquely identify each machine on the LAN. They're usually written as 6 pairs of hex numbers[ff:ff:ff:ff:ff:ff]. 

**IP Layer** uses IP adresses which is 32-bit written as 4 integers between 0 and 255. 
The latest version of IP (IPv6) uses 128-bit addresses, written as 8 2-byte hex values.
Each communication process on a machine has a unique 16-bit port number. 

**Network adversaries**
*Off-path adversaries* -> Cannot read or modify any packets sent over the connection
*On-path adversaries* -> Can read but not modify packets
*in-path adversaries* -> AKA man-in-the-middle, they can read, modify, and block packets. 
All adversaries can send packets of their own, enabling them to spoof the packet headers. 
## 26 Wired local Networks - ARP
**ARP**(Address resolution protocal) is responsible for translating IP addresses to MAC addresses. 

**ARP spoofing** it's easy to attack through the ARP protocol as anyone participating in the local network, only check the headers of the packet(not the sender) so it's very vulnerable to spoofing. You only need to be an in-path adversary to conduct an ARP spoofing attack. 

**Switches** a defense against the above attack. Using a tool like arpwatch, IP addresses can be tracked to MAC address pairings across the LAN. Modern ethernet networks uses switches to protect against ARP spoofing. The switches have a MAC cache, which keeps track of the pairings between MAC and IP addresses. By doing so the switch can return the MAC address in contrast to the recipient sending their own MAC address. "Smart" switches can also filter through which requests are broadcasted to everyone, making it more difficult for an adversary to read packets. 


## 27 DHCP(Layer 2-3)
**DHCP**(Dynamic Host Configuration Protocol) sets up the configurations when a computer first joins a local network. The settings enable communication over LAN's and the internet 
**Stuff needed to connect to the internet:**
* An IP Address
* The IP Address of the DNS server
* The IP address of the router
**DHCP handshake**
1. Client broadcasts a request for a configuration
2. Any server(Usually just one) able to offer IP addresses responds with config settings. *DCHP lease*
3. Client broadcasts which configuration is chosen
4. Server confirms that its configuration has been chosen

**NAT**(Network Address Translation) allows for multiple computers on a local network to share an IP address. 
**Attack on DHCP**
Similar to ARP spoofing. At step 2 of the DHCP handshake, an attacker can send a forged configuration, which the client will accept if it arrives before the legitimate configuration reply. If the adversary offers their own IP address as the gateway addres, they've inserted themselves as a man-in-the-middle.  They can also become an in-path adversary if they manipulate the DNS server address, enabling them to supply malicious translations between human-readable host names. 
**Defence**
Many networks simply accept that DHCP spoofing happens, and rely on higher layers to defend against the attackers. They have to rely on that as the server/client can't trust anyone at this level. 

## 30 Transport layer(4) - TCP, UDP
**UDP**
![[Pasted image 20240903193046.png]]
*note that the checksum is non cryptographic*

**TCP**
![[Pasted image 20240903193248.png]]

**TCP handshake**
![[Pasted image 20240903193413.png]]
**Attack on TCP: TCP Packet Injection**
The adversary spoofs a malicious packet, filling in the header so that the packet looks like it came from someone in the TCP connection.
*RST injection* The attacker sends a packet with the RST flag, causing the connection to abruptly terminate, this is useful for censorship. 

*Off-path adversary* To attack the TCP communication, this adversary must know the values of the client IP, client port, server IP, and server port. They must also guess the sequence number to inject into the communication, to not get detected the seq number needs to be in proximity of the actual value. The probability is 1/2^32.

*On-path adversary* They can read the IP addresses and ports as well as the seq number, so they can in fact inject messages into a TCP connection. That enables them to race the communication from either server or client, with their own spoofed packet. 

*In-path adversary* They can both block and modify messages from either party. 

**Defence**
The problem is that TCP doesn't guarantee confidentiality or integrity, so we rely on TLS to secure TCP cummunication with cryptography. 
## 32.1 - 32.4
**DNS tree hierarchy**
![[Pasted image 20240903200104.png]]
*Mapping from DNS query to "eecs.berkely.edu*
![[Pasted image 20240903200236.png]]
*DNS message format*(uses UDP)
![[Pasted image 20240903200408.png]]

## 34 Denial-of-Service (DoS)
A DoS attacks attempts to cause the service to be unable to perform its basic functionality, uusally through exhausting the resources of a service bottleneck. This can happen by exhausting the bandwidth of a server(creating so many requests that the servers processor can't keep up). In order to do so the attacker needs to create unique IP addresses for each packet sent, as to not alert the service of the attack as well as to make it difficult for the server to identify the attacker. 

**Application level DoS**
attacks the resources of an application and exploits features of the application itself. Defense against such an attack is usually three-pronged:
1. The service must be able to distinguish different users and require some method to identify or authenticate them(This process can be vulnerable to an application level DoS... )
2. You must isolate one user's actions from other users experience
3. Control the amount of resources a user can have - Assign roles so that only trusted user can use expensive requests, introduce proof-of-work through CAPTCHAS making it more expensive for the adversary to attack. 

**SYN Flood attacks**
The attacker sends a large number of SYN packets to the server, and never replies with the ACK response, this approach utilizes that a Server awaits for certain time after having send a SYN/ACK response - Causing the server to "wait" a lot. The memory of the server will fill up with seq numbers from this attack, which in turn blocks out legitimate requests. 

**DDoS**
Attackers leverage the power of many machines to direct traffic against a single website in an attempt to create DoS conditions. 
## 35 Firewalls

**Firewall**
* The general principle for Firewalls is the bugs present in code that you do not run cannot hurt you. Which means the less functionality it provides, the less opportunity for security vulnerabilities in that functionality.
* In network terms, this can translate to turning off every unnecessary network service - Which results in a stripped down box running with the least amount of code necessary.
* A firewall is designed to block access to network services that are running on internal machines. 
**Firewall policies**
* Default-allow or blacklist
	* By default every network service is permitted. 
	* More convenient functionality wise, but more dangerous in a security perspective.
	* Fails-open instead of fail-closed(Not failsafe.). 
* Default-deny or whitelist
	* Every network service is denied to external users, unless it has been specifically listed as allowed. 
	* Much safer option, less prone to human error. 
	* Most firewalls use this type of policy. 
**Stateful packet filters**
They are used in choke points,  to enforce a security policy on incomming traffic. It's a router that checks each packet against the provided access control policy, if the policy allows the packet it's. forwarded on towards its destination, if not then the packet is dropped. 

Stateful it this context means that the packet filter maintains state of all open connections that have been established. When a packet is processed, the filter allows the firewall to check whether it's part of an already open connection. 

**Firewall principles**
The mechanism that enforces control policy, is often a *reference monitor*. Which has the purpose of examining every request to access any controlled resource, and determine whether that requests should be allowed.  Any reference should have these security properties

*Unbypassable*
Assuming that the packet filter is palced on a chokepoint with the property that all communications between internal and external networks must traverse this link, then the packet filter has the opportunity to inspect all packets. 
*Tamper resistant*
One way to keep the packet filter tamper resistant, is to use a firewall on it itself, only allowing management access for a select amount of trusted machines. Combined with protecting the physical location of the packet filter device. 
*Verifiable*
The correctness of a firewall's operation is generally not verified systematically, due to the software being too complex. This can introduce bugs over time, that can allow an attacker to defeat the intended security policy by sending unexpected packets that the firewall can't handle well. 

Firewalls provide **ortogonal security** which means it can be deployed to protect pre-existing legacy systems. 

**Firewall advantages**
* Central control
	* When security policies change, only the firewall has to be updated. 
* Easy to deploy
* Cheap solution to vulnerabilities in network services*
**Firewall disadvantages**
* By reducing connectivity, you will meet loss of functionality - as you're turning off functionality by default. 
* Malicious insider problem - Firewalls are built on the assumption that insiders are trusted, which means if an insider is malicious they have the power to violate the security policy. The firewall only works against outside intruders. 
* Adversarial applications can occur when combining the two above mentioned problems. 


## Foundations of Networking

**Dolev-Yao model** If the adversary has complete control of the network they can:

* Intercept messages
* Replay messages
* transform messages
* insert messages
* delete message 
* The adversary can't guess our secrets

**Protocol layers and their headers**
![[Pasted image 20240904101741.png]]


## Attacks on Network Stack
### Attacks on the physical layer
* Eavesdropping(Counters confidentiality) If frames are broadcast, everyone can see them*
* Tampering (Counters integrity) malicious changes aren't easily detected
* DoS(Counters availability) With enough noise on the line, one can't send or receive messages
* Message injection - Arbitrary messages can be put on the wire. 

### Attacks on data-link layer
* Tampering **Cyclic Redundancy Check(CRC)** is cryptographically weak
* Message injection/MAC spoofing
* Eavesdropping - With switches the adversary can cause a MAC flooding

**MAC flooding** If you transmit enough fake frames with the new src addresses then the switches table contains no contains actual addresses.

### Attacks on Network layer

The network layer is very susceptible to spoofing: 
**ARP Cache poisoning** -> Can cause traffic to be redirected to a malicious machine, this enables for local DoS attacks. 

**IP spoofing** -> Can redirect the traffic of messages

**DHCP starvation** ->Uses spoofing to make the automatic IP assignment overwhelmed,  this allows for local DoS attacks

**Remote DoS** In the network layer can happen with:
* Ping flooding
* IP fragmentation attack
* Distribute the attack from many attacking machines for maximum effect

### Attacks on TCP layer

**TCP sequence prediction attack**
One can hi-jack a connection from Host A to B, because the TCP seq numbers are sent in clear text. So a Dolev-Yao adversary can eavesdrop on the seq number, listen to B's traffic, kill their connection, and then spoof TCP packets to A. 

**TCP RESET attack**
Spoof a TCP RST flag, that terminates the communication. This may require TCP-seq prediction attack in order to bypass the firewall. 

**TCP SYN flood**
The adversary sends a lot of SYN requests, while ignoring the SYN-ACK response and never sends the ACK-response, this exploits that the server awaits the ACK-response for some time, eventually exhausting the resources of the server. This attack is cheap. 


## Denial of Service(DoS) attacks

Can impact these resources: 
* Network bandwidth
* System resources
* Applicaiton resources

### Flavors:
**Ping flood**
Send the max-size ping at the maximum rate to overwhelm the receiver. 

**Source address spoofing**
Ping packets are returned to sender, the adversary wouldn't want that

**UDP flood**
Same idea as ping floot, but with UDP
It targets a specific port, the target returns a UDP-reply or ICMP message which consumes both bandwidth and local resources. 

**SYN spoofing**
Mentioned above, it's cheap and consumes the buffers on the server side by leaving the TCP handshake hanging. 

**DDoS**
Basically any DoS can become stronger by using multiple machines. 
Needs a lot of zombie devices, through a botnet they're instructed to DDoS a target, by arranging the zombies in a hierarchy you can make a command-and-control attack. 

**Amplification attacks**
Tries to generate more than one reply for each spoofed request. 
![[Pasted image 20240904113855.png]]

### Defenses against DoS
It's important to know that you can't entirely negate the risk. 
But you can use **DNS reflection**, which uses the firewall to block replies to requests with unknown sender, and **Amplification via IP broadcast**, which uses the firewall to block broadcasts from outside the local network. 

![[Pasted image 20240904114112.png]]


## Firewalls and intrusion Detection Systems

Works for most of the attacks except DoS. Firewalls are pieces of software and dedicated hardware, that try to detect some patterns in network traffic and determine whether or not they should be allowed. 

**Packet filtering firewall** - The simplest form of firewall,  keeps track of which ports or IP addresses can communicate to which ports and which IP addresses. By default everything is denied, and only the services necessary are allowed to pass through the firewall. It does not concern anything in the packets.

**Stateful packet inspection firewalls** - Detects when an external device connects to a device and vice versa - It keeps the state of TCP connection. Allows for more fine-grained selection. 

Firewalls can be at application level or circuit level. 

**IDS** are usually placed right behind the preliminary firewall. They detect patterns that might indicate that an attack is going on. 
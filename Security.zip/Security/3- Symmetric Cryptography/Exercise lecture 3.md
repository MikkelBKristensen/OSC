
# Review question 2.1: How is cryptanalysis different from brute-force attack

Brute-force attacks relies on attempting to try as many attempts/combinations as possible in-order to gain information, usually by doing something in order. 

Cryptanalysis can take outside sources to help with breaking a code, as Bernard showed with the Mono Alphabetic substitution, where the attacker had to take multiple steps in which they used the original language of the message to decipher the plaintext. 

# Review question 2.5: What is a one-way hash function
This supports the property *preimage resistant*, that proclaims that given an output y, it should be infeasible to find any input x such that H(x) =y. So basically from an output it should infeasible to find the given input that results in the output. 

*Infeasible* in this context means that there are no known ways to accomplish it, with any realistic amount of computing power. 

So to answer the question a one-way hash function, is a hash function that secures the aforementioned property. 

# Problem 2.1: 
**Description**
Typically, in practice, the length of the message is greater than the block size of the encryption algorithm. The simplest approach to handle such encryption is known as electronic codebook (ECB) mode. Explain this mode. Mention a scenario where it cannot be applied. Explain briefly why it is not a secure mode of encryption.

**Answer**
In ECB mode:
* The message is broken into n-bit blocks [M1...Ml]
* Each block is encoded with using the block cipher 
		*$$ C_i = E_k(M_i)$$
 * The encrypted message blocks are then concatenated into the Ciphertext. 
*Security*
It's insecure as redundancy in the blocks is shown in the ciphertext, which is visible to eavesdropper.

*Scenario*
ECB mode can only handle messages that are bit-sized divisible by n - As it doesn't use padding. Specially useless with primenumber sized messages. 
# Problem 2.6: 

**Description**
Suppose H(M) is a cryptographic hash function that maps a message of an arbitrary bit length on to an n-bit hash value. Briefly explain the primary security requirements of the hash function H. Assume that H outputs 16-bit hash values. How many random messages would be required to find two different messages M and M' such that H(M) = H(M′).

**Answer**

*Security requirements*
* *One-way*: It should be infeasible to find the input from the output of the hash function
* *Second preimage resistant*:  It should be infeasible given input x to find another x' that yields the same output. 
* *Collision resistant*: It should be infeasible, given two inputs that are not the same that they would yield the same output

*# random messages*
$$ 2^{16} + 1 $$

# Problem 2.7: 
**Description**

## Chapter 5 Intro to Cryptography

Cryptography aims to fulfill three main security properties: 
* *Confidentiality
	* Property that prevents adversaries from reading our private data. A confidential message is a guarantee that an attacker doesn't know its contents. 
	* Most cryptographic algorithms that guarantee confidentiality work like this: First A uses a key to encrypt a message, she send the encrypted message over an insecure channel to bob, bob then uses his key to decrypt the message.
* *Integrity*
	* Is the property that ensures an adversary hasn't tampered with the payload. Integrity also ensures that if a message has been tampered with, then it will be detectable. 
* *Authenticity*
	* Is the property that ensures who created a given message, if a message has authenticity then we can be sure that the person claiming the created the message actually is the creator. 

Before you can prove authenticity you must ensure integrity.
Most cryptographic algorithms that guarantee integrity and authenticity works as follows, A generates a tag/signature on a message, sends the message with the tag to B, B verifies that the tag is valid. If tampered with the tag verification would fail. 
![[Pasted image 20241227235435.png]]

*Symmetric key encryption* 
A uses SK to encrypt message, b uses same SK to decrypt message.

MAC's (*Message Authentication Codes*) provide integrity and authenticity, A uses the shared SK to generate a MAC on their message, and B uses the same SK to verify the MAC. 

*Public-key encryption* 
B generates matching Public and private keys, then shares the public key with A. A encrypts their message under B's public key, and then B can decrypt using their private key. 

*Digitial signatures* are used in PK-encryption to provide authenticity and integrity. A computes a digital signature using their private key, appends it to the message and then B can use A's public key to verify that the message has not been tampered with. 

**Cryptographic primitives**
Note: These do not guarantee any of the CIA
* *Cryptographic hashes*
	* Enables a user to condense a long message into a short sequence, of what appears to be random bits. The hashes are irreversible, so it's difficult to go back to the plaintext from a hash. but you can quickly verify that a message has a given hash. 
* *Random bits*
	* Needed in many cryptographic systems and problems, a small amount of randomness is stretched into a long sequence to make it indistinguishable from random data. 
* *Key exchange schemes*
	* Needed to allow A and B to use an insecure communication channel

**Kerkhoff's Principle**
A system should be secure even when an attacker knows all internal details of the system. In symmetric encryption this is true as long as the secret key remains secret - The system should also be implemented in such a way that it's easy switch keys when they're expected to have been leaked. 

**Threat models (Eavesdropper Eve)**
1. *Ciphertext-only attack* - When Eve has intercepted a single encrypted message and wishes to recover the plaintext.
2. *Known plaintext attack* - When Eve has intercepted an encrypted message, and already knows some information about the plaintext. Even though the plaintext is partially known, we consider Eve to have complete knowledge of that instance of plaintext.
3. *Replay attack* - Eve repeats an intercepted message from Alice to Bob, and relays that message repeatedly to Bob.
4. *Chosen plaintext attack* - Eve first tricks Alice to encrypt arbitrary messages of Eve's choice, usually generating some predictable response, Eve will then use this information to try and decrypt another message from Alice intercepted by Eve.
5. *Chosen cipthertext attack* - When Eve tricks Bob into decrypting some ciphertext, and then uses that information to learn the ciphertext of another decryption.
6. *Chosen-plaintext/ciphertext attack* Combining the the above attacks - First get Alice to encrypt some message of Eve's choosing, then tricking Bob to decrypting another message - To learn the decryption of some other text from Alice. This is the most serious threat model of the six. 

## Chapter 6

### 6.2 XOR-review
Symmetric-key encryption of relies on the bitwise XOR, which has these properties:
![[Pasted image 20241228204824.png]]
The identity being 0, x being it's own inverse, it's commutative and associative
![[Pasted image 20241228205618.png]]
### 6.3 One Time Pad (OTP)
A symmetric key encryption scheme:
A and B share an n-bit secret key, where each bit is picked uniformly at random.  
*Desired properties of the encryption scheme:*
* Should scramble message
* It should be easy to recover M from C when knowing K
* Eve should not get anything information about M without knowing K

In OTP encrypting happens by XOR'ing m and k bitwise, meaning a n bits long message, needs a n-bit long key. 
We can then decrypt C by using the jth bit of the K xor'ed on the jth bit of the C. 

An OTP is information-theoretically secure, because it leaks precisely zero information about its plaintext. the drawback being that a shared key cannot be reused to transmit another message. Else it would allow Eve to obtain partial information of the cipthertexts, by XOR'ing the two ciphertexts. 

**Drawback in text:**
![[Pasted image 20241228211838.png]]

### 6.4 Block ciphers
Instead of using an OTP like scheme, with a one time use key, most symmetric-key encryption schemes use key that can be used to repeatedly encrypt and decrypt messages between A and B. The Block cipher is fundamental for this type of scheme. 

A block cipher transforms a fixed length, n-bit input into a fixed length n-bit output. A block cipher has 2^k different settings for scrambling, which also means that it takes a k-bit key as input to determine which scrambling setting should be used. The idea being an attacker not knowing the key, would not know which scrambling settings was used and therefore won't be able to encrypt the block cypher. 

**Description in text:**
![[Pasted image 20241228214156.png]]
The most common implementation of block cipher today, is the **AES(Advanced Encryption Standard)**
AES used a block length n = 128 bits, k = 128 bits, but can also support k = 192 and k = 256. 
### 6.6 Block Cipher Modes of Operation [ONLY ECB and CBC]
AES is not IND-CPA secure, as it can't take arbitrarily long messages and two identical plaintexts would create identical ciphertexts. 
##### ECB MODE Electronic Code Book
In this mode M is broken into n-bit blocks, and each block is encoded using the block Cipher 
$$ Encryption: C_i = E_K(M_i)$$
$$ Decryption: M_i = D_K(C_i)$$

The ciphertext is just a concatenation of the individual outputs from the encryption process. The scheme is flawed, as any identical blocks will show through the encryption. So ECB mode leaks information. 
$$ Info-leak: M_i = M_j -> C_i = C_j$$
![[Pasted image 20241230084133.png]]
![[Pasted image 20241230091416.png]]
Encryption diagram of ECB
##### Cipher Block Chaining(CBC) MODE
Popular mode for commercial applications. 
1. For each message the sender picks a random n bit string called *initial vector*, $$C_0 = IV$$
2. The Ith ciphertext block is given by $$C_i=E_K(C_{i-1} XOR M_i)$$
3. The ciphertext is the concatenation of the IV and the individual codceblocks. 

This mode provides strong security guarantees on the privacy of the plaintext message, assuming that the underlying block cipher is secure. 

![[Pasted image 20241230091347.png]]
![[Pasted image 20241230091437.png]]
![[Pasted image 20241230091452.png]]
### 6.8 Padding 
Depending on which mode is being used, handling small messages vary. 

in *CBC* mode, if the plaintext length is smaller than 128 bits, then the last block of plaintext will be slightly shorter than 128 bits. This can't work as XOR only works when the two inputs are the same length.  So we add padding to the plaintext.

When adding padding we can't just add all ones and remove then afterwards, but then when we have to remove it there will be some ambiguity as to how many 1's needs to be removed.

**PKCS#7^5 padding** in this scheme we pad the message by the number of padding bytes used, so if 3 numbers were added, we would add "333" as padding. To remove we read the numbers of padding and then we can remove with unambiguously. 

not all modes need padded plaintext input, *CTR* is one example. 


### 6.9 Reusing IV's is insecure
ECB is not IND-CPA secure, because it's deterministic. All other modes introduce a random IV.
The IV must changed after each encryption. 


## Chapter 7
A hash function, H, is a function that when applied to a message, M, can generate a fixed-length fingerprint of the message. Any changes to M will change the resulting hash-value in a seemingly random way.

A hash function is deterministic.
It's also unkeyed as it only takes in a message M. 

Typically the output of a hash function is a fixed size, SHA256 is a hash algorithm used to hash a message of any size into a 256-bit hash value. 

##### Properties of Hash Functions

**One-way (preimage resistant)**
Given m it's easy to compute H(m), but given y it's infeasible to find an m such that H(m) = y.

**Second preimage resistant**
Given an input x, it's infeasible to find another input x' such that H(x) = H(x') but x=/=x'.
The property claims that given an input it is infeasible to find another input that has the same hash value.

**Collision resistant**
It is infeasible to find any pair of messages x, x', such that x=/=x' but H(x) = H(x'). 
No hash function is completely collision-free, as there are more input than output however it's infeasible for an attacker to find a collision.

*infeasible* in this context means there is no known way to accomplish it with any realistic amount of computing power. 

In some threat models, hash function can be used to verify message integrity. 
##### Hash Algorithms
MD5(Message Digest 5) and SHA1 = Insecure

Today there are 2 primary types of hash algorithms that are believed to be secure: *SHA2* and *SHA3*. 
*SHA2* -> SHA-256, SHA-384, SHA-512 
*SHA3* -> SHA3-256, SHA3-384, SHA3-512 

In practice they are very different, but the most significant difference is that SHA2 is vulnerable to length extension attacks:
![[Pasted image 20241231151342.png]]
In general we like to use hash functions that relates to the symmetric encryption scheme. Ex. AES-128 pairs with SHA-256, as it would take 2^128 operations to break the key, and 2^128 operations to generate a hash collision. This only holds up until 256b AES, as we would then use SHA-384, not 512. 

## Chapter 8 Message Authentication Codes(MACS)

### 8.1 Integrity and authenticity
When building cryptographic schemes that guarantee *integrity* and *authentication*, the relevant threat comes from adversaries who send messages pretending to be from a legitimate participant(*spoofing*) or does who modify messages sent by a legitimate partner(*tampering*)
MACs enables the recipient to detect spoofing and tampering, and provides the aforementioned guarantees. 

### 8.2 MAC: Definition
A MAC is a keyed checksum of the message that is along with the message.
* It takes a fixed length secret key and an arbitrary-length message 
* And outputs a fixed-length checksum. 
* Any changes to the message will render the checksum invalid in a secure MAC.

MAC on a message F(K, M) is computed from key K and Message M, the value being the tag or "MAC of M", one could use 128-bit key to 128-bit tags.

Flow of MACs in symmetric environment:
1. A Computes a MAC T=F(K,M), and sends the message MAC {M,T} to B
2. B recomputes T=F(K,M) and checks if it matches MAC T
3. If it matches B will accept M as valid, authentic and untampered
4. If not B will ignore the message and presume tampering or message corruption has occurred.

MACs must be deterministic for correctness. 


### 8.3 MAC: Security properties
if an attacker replaces M by some other message M', then the tag will almost certainly(1/2^128) no longer be valid as:
$$ F(K,M) != F(K,M') $$
For any M' != M. 

Essentially meaning that no attacker can simply modify the message and then take the modification to the tag to trick Bob into accepting the message. 
An attack should be unable to find a valid tag for different message such that:$$T = F(K,M')$$
MACs are designed to ensure that even small changes in the message results in unpredictable changes to the tag. 

MACs are designed to be secure against *known-plaintext attacks*. 


### 8.5 HMAC (Hash Message Authentication Code)
* HMAC is one of the best MAC constructions available. 
	* It uses the properties of a cryptographic hash function to construct a secure MAC algorithm

* HMAC combines the benefits from MAC and Hash functions - Without the key, the tag leaks no information about the message, and even with the key it's computationally difficult to reconstruct the message from the hash output. 

* The underlying hash depends on the application, examples would be HMAC_SHA3_256, that uses SHA3 in 256 bit mode.
	* When using HMACS with block cipher we need to choose an HMAC with twice the length of the keys used for the associated block cipher, meaning if we use AES_192 we should use HMAC_SHA_384
	
* HMAC is a version of NMAC, that uses one key instead of 2 
	* NMAC(K1,K2, M) = H(K1 || H(K2 || M)), K1, K2, and hash output have length n
	* HMAC(M,K) = H((K'XOR opad) || H((K' XOR ipad) || M))
	* HMAC supports variable key length, but NMAC doesn't so for HMAC we pad they key with zeros to fit n bit if it's too short, if it's too long we hash the key to fit n-bits, the transformed n-bit key is denoted K'. 
	* The unrelated keys property from NMAC is satisfied by XORing with two different pads(opad -> outer pad, ipad -> inner pad)
		* opad is the byte 0x5c repeated until it reaches n bits
		* ipad is the byt 0x36 repeated until it reaches n bits.
	* HMAC is provably secure because the unrelated keys property is guaranteed, and then it can "borrow" the fact that NMAC is provably secure. 
### 8.6 MACs are not confidential
* MAC does not guarantee confidentiality on the message M to which it is applied
* MACs provide integrity and authenticity

# Advanced Encryption Standard (AES)
## Overview of the Algorithm
* Uses block length of 128 bits
* Uses key length of 128, 192, 256 bits
* AES does not use a Feistal structure, instead it processes the entire data block in parallel during each round using substitutions and permutation. 
* The key is expanded into an array of 44 32 bit words, - 4 words serve as round key for each round
* 4 stages are used, one for permutation and 3 for substitution
	* *Substitute bytes* - Uses an S-box to perform a byte-by-byte substituion of the block
	* *Shift rows* - Permutation that is performed row by row. 
	* *Mix columns* - Substitution that alters each byte in a column as function of all the bytes in the column
	* *Add round key* - Bitwise XOR of the current block with a portion of the expanded key. 
**Svært at notere over, men har downloadet filen**

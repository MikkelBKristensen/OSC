#confidentiality #cryptography 

**Look up Cyclic groups**

# Symmetric cryptography
*Motivation* 
we want to protect data confidentiality integrity and availability on insecure networks. 
Based on strong mathematical foundations: Proven to be secure instead of conjectured. 
We use these tools every day, to access websites and services securely. 
## Symmetric cryptography For **Confidentiality**
Uses a method that takes a key to encrypt a message, that can only be decrypted with the key. In the symmetric case, we only have on key, both for encryption and decryption. 
![[Pasted image 20240911102659.png]]
*Correctness* once you encrypt a plaintext you should be able to decrypt it with the same key. 

*Symmetric encryption protects confidentiality of encrypted messages.*  -> Authenticity is not ensured, a Dolev-Yao adversary could scramble the message, and then nobody would be able to decrypt the message. 
### Caesar's cipher
Offsets the alphabet by the key, so if key is 2 then 'A' -> 'C', 'B' -> 'D' and so on. 
This encoding can be decoded by brute forcing each message, with all the shift possibilities. In this case there are 25 possibilities, as there are 25 letters. 

### Mono alphabetic substitution
Random permutation of characters(A -> N B-> F, it's random silly), The key space with this approach 26!, which disables brute force approach. 
Still not perfect, as you can use which language the plaintext is in, to see which letters are more frequent to analyze the cipher. 
The frequency of characters in the  original language can be superposed on the frequency of the cipher characters, and then you get a semi solved cipher text - But slowly approaching a guessable plaintext. 
The next step is to find small words, and their frequency and compare them to the frequency in the original language. 

**This encryption scheme is not secure**
### Perfect secrecy
Vernam cipher or OTP
Idea use XOR operations to encrypt or decrypt. 
![[Pasted image 20240911105233.png]]
XOR with they K encrypts message, XOR with key again the key gets decrypted, due to a bit being xor'ed with itself produces the 0 bit. 
The problem is that the key **can only be used once**, and the key must be the same length as the message. 

*OTP is secure even against adversaries with unlimited computational power*

### Block cipher

**CBC**
The randomness is in the initialization vector(IV) that is one block long. 

## Hash and MAC for **Integrity** and **Authenticity** 
Hash functions are used in many security mechanisms:
* Compare by hash
* virus protection
* OTP
* Storing passwords
* fundamental ingredient for many crypto primitives*
### Hash definitions
![[Pasted image 20240911113838.png]]

3 main properties:
It should be hard to invert the function

A message and an output should make it hard to decode another message

It should be hard to find hashes that are equal
![[Pasted image 20240911113946.png]]
**HASH FUNCTIONS DOESN'T PROTECT AGAINST CONFIDENTIALITY**


### MAC
![[Pasted image 20240911114521.png]]
![[Pasted image 20240911114747.png]]

### Applications


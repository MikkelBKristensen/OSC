## 1 Prove that they are groups

Rules for groups:
![[Pasted image 20240918122129.png]]

**Demonstrate that the following are groups. State what are the neutral elements and inverse operations**

### 1.1 Integers with addition. 
*Use things you know*

**Closure**
Er overholdt, da all operationer på to integers der tilhører integers vil resultere i et nyt integer, som altså er inde i gruppen.

For any x, y belonging to Z x+y belongs to Z. 

**Identity**
Identity er overholdt, da  0 + x = x. 

**Inverse**
For any x belonging to Z there is a -x such that x +(-x) = 0

**Associativity**
Overholdt med addition (x+y)+z= x+(y+z)

**Commutativity**
Overholdt da:
x+y = y+x

### 1.2 16-bit strings with xor
![[Pasted image 20240918123344.png]]
**Closure**
Da 16 bit xor ikke ændrer på længden af det word der bliver xor'et vil resultatet af operationen stadig tilhøre mængden af 16-bit strings. 

**Identity**
The identity is all zeros, as 0 xor 0 is 0 and it only evaluates to 1 if the two are different. 
**Inverse**
Alle ord har et inverse, i form af sig selv, da et bit xor sig selv er 0. 
**Associativity**
I calculated an example, and that didn't hold, but who knows. 
**Commutativity**
Is upheld as 1 xor 0 = 0 xor 1, so the order of the operations doesn't matter. 

### 1.3 The numbers from 0 to 19 with wrap-around addition (18+1 = 19, 18+2 = 0, 18+3 = 1, ...)
**Closure**
Overholdt, da tallene aldrig forlader mængden når man kører wrap-around addition på to elementer fra mængden. 
**Identity**
Identity er weird her - er ret sikker på at det er 0 for x der tilhører mængden
**Inverse**
I det her tilfælde så er det x +(20-x)
**Associativity**
Overholdt, rækkefølgen af operationerne er ligeggyldige
**Commutativity**
$$ (12+7) \% 20 = (7+12 )\% 20$$

## 2 Prove that they are not groups

### 2.1 Integers with multiplication

**Closure**
Alle integers ganget med en anden integer forbliver en integer
**Identity**
 is 0 as x * 0 = 0 for any x belonging to Z

**Inverse**
There is no inverse, other than the identity itself, and I'm not sure if it's allowed. 

**Associativity**
$$ (x*y)*z = x* (y*z)$$

**Commutativity**
$$ x * y = y * x $$
### 2.2 Lists with list concatenation.

**Closure**
A list concatenated with a list is still a list

**Identity**
An empty list concatenated with a list doesn't change anything

**Inverse**
You cannot concatenate a list such that you get fewer entries than the original, making it impossible to achieve the identity list. 

**Associativity**
You'll receive a different result depending on which list is concatenated 

**Commutativity**
It does matter how you concatenate a list, as the resulting order is affected by which list is first. 

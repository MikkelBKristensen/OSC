# Asymmetric Cryptography for confidentiality and Authenticity

**The motivation for asymmetric cryptography** is found in the limitations of symmetric cryptography. We need to meet in person to securely choose keys. We need a key for each pair of agents.  It's difficult to do securely over an insecure network. 
Asymmetric cryptography is very slow compared to symmetric cryptography. This is why we want asymmetric encryption to securely exchange symmetric keys. 

## Abelian groups

* A group is a pair (Set, binary operation)
We're gonna use Cyclic groups. 

## Diffie Helmann key exchange
The primitive used to establish a symmetric key over an insecure network such that a dolev-yao adversary can get the key. 

in the end of the procol they want to have the same key, but in the beginning they only share the knowledge of the protocol. 
![[Pasted image 20240918104048.png]]
This type is slow, as p would be in the order of 4096 bits which takes a toll on the communication. 

![[Pasted image 20240918104136.png]]

here we use a much smaller group, instead of integers, with the size of  256 bits - It's so much faster. 

The adversary that can see g^x and g^y still can't solve for the key, as they don't know either x or y. As the problem is currently unsolved it's inconceivable that the adversary would be able to solve it. (It's a variant of the discrete log problem). The actual problem the Diffie-Hellman is based on is called Computational DH. 

![[Pasted image 20240918105121.png]]
## Asymmetric encryption
* Every secret key(Used to decrypt plaintext) has an inverse public key(Used to encrypt plaintext)
* Its hard to compute the secret key from public information

The goal is to guarantee message confidentiality. And to provide security under well studied mathematical assumptions. 
![[Pasted image 20240918110318.png]]
![[Pasted image 20240918111534.png]]

### RSA Encryption
The first publicly published encryption scheme using public and private keys. It's not broken yet, but it's not used anymore due to its efficiency.
RSA uses a key length of 4096 bits. 
### El gamal(Based on elliptic curves) encryption
Allows to use the group structure in a generic way, which makes the algorithms faster. 
El gamal uses a key length of 256 bits. 

## Digital signatures
![[Pasted image 20240918114810.png]]


## Hand-in 1 assignment
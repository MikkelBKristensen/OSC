## Chapter 10 Diffie-Hellman key exchange
The goal of DH is to create an ephemeral key, which is then used in a series of encryptions and decryptions before being discarded. 
DH is a way for two parties to agree on a random value in the face of an eavesdropper. 
### 10.1 Diffie-Hellman intuition

Basically:
1. A and B wants to share a secret and hide it from E
2. They agree on a public value
3. They then send their secret value mixed with the public value
4. When they received their counterparts mixture, they mix their own secret into the mixture resulting in A and B arriving at the same "mixture" without sending their pure secret value over an insecure communication channel. 

### 10.2 Discrete Logarithm problem

The mixing mentioned above works under the assumption that it is easy to mix the values and very hard to seperate them.
The mathematical equivalence is called *one-way functions*: A function that given x, it's easy to compute f(x) but given y it's practically impossible to calculate x such that f(x)=y. 

The simplest one-way function is "exponentiation modulo a prime" $$ f(x)=g^x(mod p)$$ where g is specifically chosen generator and p is a prime.
There's no known efficient algorithm to solve for x. 

DH uses the discrete log problem mentioned above.
### 10.3 Diffie-Hellman protocol
**Flow:**
1. Alice and Bob establishes p and g, both of which are public
	1. p is a large prime
	2. g must be in the range 1 < g < p-1
2. Alice picks a secret value a and computes A = g^a mod p. Bob picks a secret value b and computes B = g^b mod p
	1. a and b are from the set {0,1,...,p-2}
3. Alice announces A and Bob announces B and calculates S, while keeping a and b secret
	1. $$A: S = B^a = (g^b)^a = g^{ba}(mod p)$$
	2. $$B: S = A^b = (g^a)^b=g^{ab}(mod p)$$
4. Alice and bob can now use S as a shared key for a symmetric key cryptosystem.

DH builds on that there is no known efficient algorithm that can deduce S= g^(ab) (mod p).

### 10.6 Attacks on Diffie-Hellman
DH is only secure against a passive adversary(Eavesdropper) not an active adversary(man-in-the-middle[Mallory]). 
If an adversary can tamper with the communication between A and B, they can trick them into thinking that they've created a shared key, when in actuality they've generated two different keys that Mallory knows.
![[Pasted image 20250101224054.png]]
If this succeeds Mallory would be able to pretend to Alice that she is Bob, and pretend to Bob that she is Alice. 
This issue stemming from the fact that DH inherently has no integrity or authenticity guarantees. This could be solved with digital signatures, this would allow Alice and Bob to detect that Mallory is tampering with their messages. 
## Chapter 11 Public key Encryption
### 11.1
The problem with symmetric-key encryption is that A and B somehow has to establish the shared secret key, this is where **Asymmetric cryptography/public-key encryption** enters the chat.

In that type of Scheme, the recipient has a publicly available key, that everyone can access, and when someone wished to relay message they use the recipients public key to encrypt the message. The recipient can then use their secret key to decrypt the message.

Public-key cryptosystem is kind of a gateway to symmetric-key encryption:
1. as now A can pick a secret key K
2. encrypt it under Bob's public key
3. send the resulting ciphertext to Bob
4. Bob can then decrypt it with his secret key and recover K
5. Now they can communicate using a symmetric-key cryptosystem with K as their shared key. 

### 11.4 El Gamal encryption

A public-key encryption scheme based on Diffie-Hellman, addressing the fact that DH doesn't let neither Alice nor Bob choose the shared secret(It's random in DH).  And DH on it's own doesn't let them send encrypted messages to eachother. 

**Description:**
*Public system parameters:*
p, a large prime
g, satisfying 1 < g < p-1.

*Encryption*
1. Bob choses a random value b, as his private key, and computes his public key B
	1. b satisfies 0 <= b <= p-2. 
	2. B = g^b mod p
2. Bob published B to the world and keeps b secret
3. Alice wants to send a message m to Bob and knows his public key B
	1. m is in the range 1 .. p-1
4. Alice picks a random value r and forms the following cipher text(A pair of numbers (R,S))
	1. r is in the range 0 .. p-2 $$(g^r mod p, m x B^r mod p)$$

*Decryption*
To decrypt Alice's message, Bob would compute:
$$m = R^{-b} S mod p$$
*Explanation:*
![[Pasted image 20250101232808.png]]

In words, El Gamal encryption uses Diffie-Hellman key exchange, but the keys used are Bob's long term public key B, and Alice's fresh new public key R chosen just for that exchange. She then encrypts m by multiplying it with the shared key K modulo p. Essentially Alice uses an OTP with K as key and m as message.
**Summary:**
![[Pasted image 20250101231809.png]]
## Chapter 12 Digital Signatures
Digital signatures uses the ideas from public-key encryption to build asymmetric cryptographic schemes that guarantee integrity and authentication. 
### 12.1 Digital signature properties
Essentially digital signature wants the opposite of public-key encryption, Bob should be able to generate a signature on a message, and everyone should be able to verify the signature to confirm that the message came from Bob.

**Flow**
1. Bob generates a public key(verification key) and a private key(signing key)
2. Bob distributes his public verification key to everyone but keeps signing key private.
3. When Bob wants to relay a message he uses signing key to generate signature on message
4. When Alice receives the message, she can use Bob's verification key to check that the signature is valid and confirm that the message is untampered with. 

**Digital signature schemes consists of three algorithms:**

*Key generation* - a randomized algorithm KeyGen, that outputs matching public key and private key - Each invocation produces another key-pair. (PK, SK) = KeyGen().

*Signing* - S =Sign(SK, M), S being the signature on message M, with the signing key SK. 

*Verification* Verify(PK, M, S) returning true if S is a valid signature on M

# Introduction to group theory
Group theory is the study of algebraic structures called groups, and rely heavily on set theory and modular arithmetic. 

A group is a set and an operation. 
*Examples of groups:*
![[Pasted image 20250102112143.png]]

#### Properties of groups
**Closure under the operation**
For the group (G, * ) where G is a set and * is a binary operation, if a,b are in G then (a * b) is also in G, this is called closure. 

**Associativity**
For the Group (G, * ) uf a,b,c belongs to G then:
$$ a *( b*c)=(a*b)*c$$
**Identity**
If (G, * ) is a group then there exists an identity element e in G such that for any g in G:
$$e*g=g*e=g$$
**Inverses**
If (G, * ) is a group with identity e, then there exists a^-1 for every a in G such that:
$$a*a^{-1}=e=a^{-1}*a$$

Groups don't need to consist of sets that are infinite. 

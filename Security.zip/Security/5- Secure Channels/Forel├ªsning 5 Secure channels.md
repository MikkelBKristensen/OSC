# Pulic key Infrastructures

### Security protocol
**Def**: A distributed algorithm that sees parties exchange cryptographic messages to obtain security goals. 
**Assumption**: 
* Cryptography is not broken
* An attacker cannot break cryptography
	* Perfect Hash, MAC, symmetric, and asymmetric primitives. 

### Syntax of protocol messages
**Atomic**:
*Party names:* A, B , M, TTP
*Keys* sk_a, sk_b, pk_a, pk_b
*Nonces* N_a, N_b <-Random numbers that are used only once
*Timestamps* T_1, T_2

**Compund**: 
*Concatenation*: m, m'
*Ciphertexts*: {m}\_pka
*Signatures*: {m}\_ska

# Improved Diffie-hellman (Authenticity/Integrity)
Is vulnerable to MITM attacks as it does not guarantee integrity or authenticity. 
In order to do so, We need to implement digital signatures. 

### Digital certificate
**Goal**: Link a public key to its owner

The problem with this approach is that the public key/Verification key needs a third-party/database for distribution allowing for usage of signatures. The problem is "solved" with digital certifications provided by a Certificate Authority(CA).

Two types: Domain validated(Cheap and automated) and Extended validation(Expensive because of manual checks) certificates



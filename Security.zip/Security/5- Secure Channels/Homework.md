# Chapter 13 Certificates

## 13.1 Man-in-the-middle Attacks
The process of exchanging keys is a process that is vulnerable to MITM attacks. They're possible when there's no way to authenticate the public keys of the people wishing to communicate over an insecure channel. 

The strategy against this is to ensure that every participant can verify the authenticity of other people's public keys. 

## 13.2 Trusted Directory Service
A service that keeps a relation between a name and a public key, such that participants can ask for the public key of their intended recipient. 

The public key of that service, can be hardcoded into whichever applications needs to use the service, as to not just propagate the key management problem further. 

**TDS suffers under these shortcommings**
* *Trust*
	* Trust of the directory service is need, everyone depends on the honest operation of the directory service
* *Scalability*
	* The directory service is a bottleneck for everyone trying to contact anyone new.
* *Reliability*
	* It becomes a single point of failure system, if the directory service is down nobody can contact anyone new
* *Online*
	* The directory service requires online connectivity
* *Security*
	* The machines running the service needs to be connected to the internet at all times, so they have a high need for security against remote attacks. 

This system is not widely used, outside of the context of messengers where connectivity already is required. 

## 13.3 Digital Certificates
DC addresses some of the limitations of a trusted directory service, specifically: Scalability, reliability and online access. 
It's a way to represent an alleged association between a person's name and their public key as attested by some certifying party.

With digital certificates, you don't need a trusted directory service, you only need to receive a copy of the digital certificate(can be from anyone), as long as you verify the signature of the digital certificate and trust that the person(CA) who signed the certificate is both who they say they are and honest. 

## 13.4 Public Key Infrastructure PKI
*Certificate Authority (CA)* - A party who issues certificates. Their public key can be hardcoded in applications that need to use cryptography. 

Whenever an application needs a public key, they can ask the CA for a copy of their digital certificate, verify that it's properly signed by the trusted CA and extract the public key to securely communicate with intended recipient. 

DC still suffers from the fact that the CA needs to be trusted by everyone, but it's better at scalability, reliability and utility compared to an online directory service. 

This format is used to secure the web - When a website offers HTTPS(SSL), they need to buy a DC from a CA, who then checks the identity of the website and issues a certificate linking  their domain name to a public key. 

**Accessing via https:**
* When you type an HTTPS:URL in a browser
	* It connects to the website
	* Asks for a copy of the sites digital certificate
	* Verifies the certificate using the public key of the CA who issued it
	* Check that the domain name if the certificate matches the site name you're visiting
	* Establishes a secure communication with the site using the public key in the digital certificate
The more CA's your browser trusts the higher the chances of a malicious user affecting the security of everyone on the web. 

## 13.5 Certificate Chains and Hierarchical PKI
Having a single CA for everyone is not scalable, so a more realistic approach is to establish a hierarchy of responsibility - Also known as a certificate chain.  
In a state it could look like: The governor is CA an issues certificates to each head of major state agencies, delegating them the responsibility of issuing and signing certificates for employees below them. 

A Certificate chain can have any length, and the CA hierarchy is often chosen to reflect an organization. 

## 13.6 Revocation
In the above explained PKI system, there's no way to handle revocation of a wrongly issued certificate, it will be valid forever. So this needs to be considered, and there are two standard approaches:

**Validity periods**
As the name suggests the certificates here have an expiration date. 
It doesn't directly address the problem of revocation, but limits the time a erroneous certificate can exist. 
This approach forces us to make a tradeoff between efficiency and how quickly we can revoke a certificate - Too short periods would prove a hassle, but allows us to quickly revoke certificates leading to realiability problems, and too long periods would expose us to more danger.

**Revocation lists**
A list maintained by the CA of all certificates that have been revoked. This list could be digitally signed and dated by the CA, and everyone would just need to download this list once in a while and cache it locally. Then each user could verify a given certificate and check it with their local revocation list to ensure their not communicating with a malicious user. 

This approach offers the ability to respond promptly to bad certificates - and tradeoff being made here is between efficiency and the prompt response. 
The more frequently we ask users to download the list the more bandwidth the CA servers will need to handle, but the more quickly we can revoke erroneous certificates. 

The revocation list have their own challenge if a user is unable to download the revocation list, and then a malicious erroneous certificate holder DoS attacks CA then the user won't be able to detect if they're communication with a bogus certificate. 
And even worse if the user denies all certificates when they can't update the revocation list, then the attacker has the ability to deny service to all users of the network. 

Systems that use revocation lists typically ignore the risk of DoS and hope for the best. 
## 13.7 Web of trust
Is another approach, the idea here being that you can democratize the process of public key verification such that no central trusted authority is needed. Each individual can issue certificates for their friends, colleagues or whomever they want to. 

Two challenges appear in this approach
**Trust isn't transitive**
A trusting B, and B trusting C doesn't translate to A trusting C. 
**Trust isn't absolute**
"I trust my bank with my money but not my children. I trust my relatives with my children but not my money."

PGP who pioneered this approach, have developed it further to acommodate for these challenges - In their approach they store certificates to make it easier to find intermediaries, and if possible they then try to find multiple paths from sender to recipient - Trusting shorter paths over long paths.

This approach is not widely available, and PGP's solution is not founded in theory. 
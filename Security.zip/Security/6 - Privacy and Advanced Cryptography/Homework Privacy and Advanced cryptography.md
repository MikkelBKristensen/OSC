# [Lecture notes]Secure Three Party Computation via Replicated Secret Sharing - Bernardo David

## 1: Introduction
**Multiparty computation** is a protocol that allows a set of mutually distrustful parties to compute their output of a function on their private inputs without disclosing information about the inputs. 
This protocol might be secure under different adversarial models:
#### Passive vs Active adverseries
A **passive adversary** acts in an honest-but-curious way, learning the input and internal state of corrupted parties but follows the protocol exactly.
An **active adversary** can deviate from the protocol in any arbitrary way.

#### Honest vs Dishonest majority
In an **honest majority**, the adversary may corrupt a minority of the parties, meaning they can obtain the internal state and control. 
In a **dishonest majority**, the adversary can corrupt all but one of the parties. 

#### Static vs Adaptive Security
**Static security**: The adversary must choose which parties to corrupt before protocol executions start, meaning they cannot corrupt anyone during the execution.
**Adaptive security**: The adversary can adaptively choose which parties to corrupt as the execution of the protocol progresses. 

The lecture notes will describe a three-party computation protocol secure against passive static adversaries with an honest majority. This is the *weakest* security guarantee, but is meant to showcase how to compute arbitrary functions on private inputs. 
## 2: Building Blocks
**Finite field of order**: $q$
**Operations with + and \***: $F_q$
**Choosing x (uniformly)at random from a set D**: $x \leftarrow D$

### 2.1 Additive secret sharing
This simple scheme for additive secret sharing allows a dealer to split a secret $s$ into n shares $s_1, ... ,s_n$ in such a way that knowing less than n shares reveals no information of s. It can be done in two steps
#### Share $s \in F_q$ into $n$ shares
The dealer is executes these steps:
1. Sample $s_1, ..., s_n-1 \leftarrow F_q$
2. Compute final share: $s_n =s - \sum_{i=1}^{n-1}s_i$
3. Output shares $s_1, .., s_n$

#### Reconstruct $s$ from $s_1, ..., s_n$ 
$s = \sum_{i=1}^{n}s_i$

This first $n-1$ shares are picked at random, which is how it doesn't reveal any information about $s$ that you know some shares of $s$. The final share works as OTP hiding s under a key, to retrieve the secret one must know all shares. 

## 3 Three party computation
The lecture note uses simple additive secret sharing to construct the three-party computation protocol. There will be two main sub-protocols **adding** and **multiplying** inputs. 
##### High-level rundown of the protocol
The idea in this protocol, is that each party secret shares their input and gives shares to each of the other parties. Later when additions or multiplications needs to be computed, each party computes the shares they know locally and exchange the results to the other parties. 

### 3.1 Addition
Description of protocol with parties: $P_1,P_2,P_3$ And their respective secrets: $x,y,z$

#### Input
In this step each party shares its input with the additive secret sharing scheme, and distribute the shares among the other parties
1. $P_1$ obtains shares $x_1, x_2, x_3$ and sends $x_2$ to  $P_2$ and $x_3$ to  $P_3$. 
2. $P_2$ obtains shares $y_1, y_2, y_3$ and sends $y_1$ to  $P_1$ and $y_3$ to  $P_3$. 
3. $P_3$ obtains shares $z_1, z_2, z_3$ and sends $z_1$ to  $P_1$ and $z_2$ to  $P_2$. 
#### Addition
In this step, each party locally adds its own shares of the inputs in order to obtain a share of the result of the addition
1. $P_1$ obtains and share $out_1 = x_1+y_1+z_1$
2. $P_2$ obtains and share $out_2 = x_2+y_2+z_2$
3. $P_3$ obtains and share $out_3 = x_3+y_3+z_3$

#### Output
All parties privately send eachother shares of the output and reconstruct the output:
1. $P_1$ sends $out_1$ to $P_2$ and $P_3$ and upon receiving $out_2$ and $out_3$ computes out via the sum of shares. 
2. $P_2$ sends $out_2$ to $P_1$ and $P_3$ and upon receiving $out_1$ and $out_3$ computes out via the sum of shares. 
3. $P_1$ sends $out_3$ to $P_1$ and $P_2$ and upon receiving $out_1$ and $out_2$ computes out via the sum of shares. 

### 3.2 Multiplication
For this sub-protocol, we can't simply let each party compute its local shares. So we have to modify the share distribution of the input phase, such that at least one party has the shares for computing the terms of the $x_i*x_j$ where $j\neq i$.
##### Introduced weakness
This part weakens the protocol, as any 2 parties can reconstruct all inputs if they pool their shares. However one sole party cannot reconstruct all inputs, so protocol still works in the honest majority setting. 

The following walk through of handles the case where only $P_1$ and $P_2$ has inputs $x,y$ - But a protocol handling $P_3$ with input $z$ can be obtained by repeating the sharing for $z$ and computing a second multiplication step  between $x*y*z$. 

#### Input
$P_1$ and $P_2$ share their inputs using the additive secret sharing scheme, and distribute the shares among the other parties:
1. $P_1$ obtains shares $x_1,x_2,x_3$ and sends $x_1,x_2$ to $P_2$ and $x_2, x_3$ to $P_3$.
2. $P_2$ obtains shares $y_1,y_2,y_3$ and sends $y_1,y_3$ to $P_1$ and $y_2, y_3$ to $P_3$.
3. $P_3$ waits for the shares $x_2,x_3$ and $y_2,y_3$.

#### Multiplication
Each part computes their shares of the result of the multiplication. 
1. $P_1$ obtains a share $out_1=x_1*y_1 + x_1*y_3 + x_3*y1$
2. $P_2$ obtains a share $out_2=x_2*y_2 + x_1*y_2 + x_2*y1$
3. $P_3$ obtains a share $out_3=x_3*y_3 + x_2*y_3 + x_3*y2$

#### Output
All parties privately send eachother shares of the output and reconstruct the output:
1. $P_1$ sends $out_1$ to $P_2$ and $P_3$ and upon receiving $out_2$ and $out_3$ computes out via the sum of shares. 
2. $P_2$ sends $out_2$ to $P_1$ and $P_3$ and upon receiving $out_1$ and $out_3$ computes out via the sum of shares. 
3. $P_1$ sends $out_3$ to $P_1$ and $P_2$ and upon receiving $out_1$ and $out_2$ computes out via the sum of shares. 

# What is GDPR, the EU's new data protection law
GDPR applies when personal data oF EU citizens or residents are processed. Whenever services or goods are offered to such people. 
The most important reaches of GDPR:
* Personal data
* Data processing
* Data subject
* Data controller
* Data processor

#### Data protection principles 
If one processes data, it has to be done in accordance to the seven protection and accountability principles:
1. **Lawfulness, fairness and transparency** must be fulfilled by the processing
2. **Purpose limitiation** - The data must be processed for a legitimate purpose, specified explicitly to the data subject when collected
3. **Data minimization** - You should collect and process only as much data as is absolutely necessary for the specified purposes.
4. **Accuracy** - Personal data must be kept accurate and up to date.
5. **Storage limitation** - personally identifying data must only be stored for as long as its necessary for the specified purpose.
6. **Integrity and confidentiality** - Processing must be done in such a way as to ensure security, integrity and confidentiality. (encryption)
7. **Accountability** - The data controller is responsible for being able to demonstrate GDPR compliance.

#### Accountability
Data controllers must be able to demonstrate that they are GDPR compliant. You are NOT compliant if you cannot demonstrate that you are. 
Ways to demonstrate that you are compliant:
* Designate data protection responsibilities to your team
* Maintain detailed documentation of the data you're collecting, how it's used, where it's stored, which employee is responsible for it
*  Train staff and implement technical and organizational security measures
* have data processing agreement contracts in place with third parties you contract to process data for you

#### Data security
A company is required to handle data securely by implementing **technical** and **organizational measures**. 
**Technical**
* 2FA
* E2E encryption
**Organizational**
* Staff trainings
* Data privacy policy
* Limiting access to personal data

#### Data protection by design and by default
You must consider data protection principles in the design of any new product or activity. 

#### When you're allowed to process data
It's only legal to process person data if:
1. The data subject gave you specific, unambiguous consent to process data
2. Processing is necessary to execute or to prepare to enter into a contract to which the data subject is a party.
3. You need to process it to comply with a legal obligation of yours
4. You need to process the data to save somebody's life
5. Processing is necessary to perform a task in the public interest or to carry out some official function
6. You have a legitimate interest to process someone's personal data. This basis is overridden by the "Fundamental rights and freedoms of the data subject".

#### Consent
Rules about what constitutes consent from a data subject to process their information
* Consent must be freely given, specific informed, and unambiguous
* Requests for consent must be clearly distinguishable from the other matters and presented in clear and plain language
* Data subjects can withdraw previously given consent whenever they want and you have to honor their decision. 
* Children under 13 can only give consent with permission from their parent
* You need to keep documentary evidence of consent

#### Data protection officers
Not every data controller or processor needs to appoint a DPO, these three conditions under which you are required to appoint a DPO
1. You are a public authority other than a court acting in a judicial capacity
2. Your core activities require you to monitor people systematically and regularly on a large scale
3. Your core activities are large-scale processing of special categories listed in Article 9 of GDPR or relating to criminal convictions andoffenses mentioned in Article 10. 

#### People's privacy rights
A data subjects privacy rights:
1. The right to be informed
2. The right of access
3. The right of rectification
4. The right to erasure
5. The right to restrict processing
6. The right to data portability
7. The right to object
8. Rights in relation to automated decision k, NB -making and profiling. 

# Bitcoin and Cryptocurrency Technologies
## 2.2 Distributed Consensus
A key technical problem to solve when building distributed e-cash systems is achieving distributed consensus. 

In application spanning over thousands or millions of servers such as Amazon or Facebook, where the servers for a massive distributed database, each piece of information must be recorded on several nodes and they must be in sync about the overall state of the system. 

**The technical definition is:**
In a distributed consensus protocol, there are n nodes that each have an input value- Some nodes are faulty or malicious. The protocol must have the following properties:
1. It must terminate with all honest nodes in agreement on the value
2. The value must have been generated by an honest node


## 2.3 Consensus without identity using a block chain
**Implicit consensus** - Nodes will implicitly accept or reject a block by choosing whether or not to build on top of it. If a they accept a block, they will signal their acceptance by extending the block chain including the accepted block. If they reject that block, they will extend the chain by ignoring the block, and building on top of whichever is the previous block that they accepted- 
![[Pasted image 20250102214752.png]]

No user can simply steal a bitcoin even if it's their turn to propose the next block in the chain - As it would require the attacker to create a valid transaction that spends the coin and forge the owners' signatures, which isn't possible under a secure digital signature scheme. 

DoS attacks will only prove a minor inconvenience, as if A denies any transactions made by B, B would simply need to wait for an honest Node to confirm the truth and then the DoS would be nullified. 

Double-spend attack
A creates two transactions spending the same coins, one real where she buys something and one fake that either transfers the coins to another wallet or in another way undermines/cancels the legitimate purchase. Only one of the transactions can remain on the blockchain as they expend the same coins. 
In a technological perspective these transactions are identical, meaning either one of the transactions could be committed long term to the blockchain. 
However the merchant can simply delay the transfer of the product until A's transaction has been in several blocks, as that chain then would be longer than the fake transactions chain.  The magic number is to wait 6 blocks before acting as the payment has occured. 


# Protocol (MPC Addition and TLS via TCP)
Communication using TLS to ensure integrity
Encryption to ensure confidentiality 

## Patient
1. Compute 3 shares out of the  local sum
2. Start TCP-listener to receive incoming shares. 
3. Establish connection to other patients, through TCP Clients
4. Send one share to each patient
5. Receive one share from each patient
6. Compute the aggregated sum from shares received and the one that is held
7. Send result to the Hospital

## Hospital
1. Start listening on port
2. Collect results from each Patient
3. Calculate sum
4. Use for ML. 
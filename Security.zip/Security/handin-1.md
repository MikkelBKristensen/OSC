# Part 1

You are Alice and want to send 2000 kr. to Bob through a confidential message. You decide to use the El Gamal public key method. The keying material you should use to send the message to Bob is as follows: 
* The shared base $$g=666 $$ 
* The shared prime $$ p=6661 $$ 
*  Bob’s public key $$ PK = g^x mod p =2227 $$Send the message ’2000’ to Bob

**El Gamal encryption:**

1.  public system parameters are a large prime p and a value g satisfying 1 < g < p-1
2. Bob chooses a random value b satisfying 0 <= b <=p-2 and computes B = g^b mod p. 
3. Bob's public key is B, and his private key is b. Bob publishes B to the world and keeps b secret. 
4. Alice wants to send a message m in range(1 - p-1) to bob. She knows Bob's public key is B. To encrypt the message Alice picks a random value r(0 - p-2) and forms ciphertext:
	 $$ g^r mod p, m × B^r mod p $$
5. Bob decrypts the message by: 
	$$ R^-b × S mod p$$
6. And the result is the message m Alice sent him. 



```csharp
void SendEncryptedMessage()  
{  
    int AliceMessage = 2000;  
    int base_g = 666;  
    int largeP = 6661;  
    int bobs_Pk = 2227;  
    //Random number between 1 and prime  
    int randomR = new Random().Next(1, largeP-2);  
    var cipherText = EncryptMessage(randomR, largeP, bobs_Pk, AliceMessage, base_g);  
    foreach (var entry in cipherText)  
    {  
        Console.WriteLine(entry);  
    }  
}  
static List<BigInteger> EncryptMessage(int r, int p, int pk, int m, int g)  
{  
    var cipher_text = new List<BigInteger>();  
    BigInteger fst = BigInteger.Pow(g, r) % p;  
    BigInteger snd = m * BigInteger.Pow(pk, r) % p;  
    cipher_text.Add(fst);cipher_text.Add(snd);  
    return cipher_text;  
}  
  
SendEncryptedMessage();
```

# Part 2

**You are now Eve and intercept Alice’s encrypted message. Find Bob’s private key and reconstruct Alice’s message.**

We know Bobs public key B as this is broadcasted on the network(To the world?)
We also know g=661 and p=6661 As these values are part of the public system parameters

> "The public system parameters are a large prime p and a value g satisfying 1<g<p−1 ."
> **11.4 "El Gamal Encryption"** - https://textbook.cs161.org/crypto/public-key.html 

This means we can assume that Bob's secret key lies within the range of [1:6661-2]. 
We can use this information to bruteforce our way to his secret key, by finding the x such that:
$$ g^x \%p = 2227 $$
After finding Bobs secret key we can decrypt the cipher text(R,S) as intended: 

$$ R^-b × S \% p$$

# Part 3
*You are now Mallory and intercept Alice's encrypted message. However, you run on a constrained device and are unable to find Bob's private key. Modify Alice's encrypted message so that when Bob decrypts it, he will get the message 6000.*

**Available information**:
* Bob's pk : $$B=g^x $$
* Alice's pk : $$A = g^r$$
* g: 666
* p: 6661
* Alice's message: $$c_1 = g^r mod p$$
$$c_2 = m × B^r mod p = m × (g^x)^r mod p $$
